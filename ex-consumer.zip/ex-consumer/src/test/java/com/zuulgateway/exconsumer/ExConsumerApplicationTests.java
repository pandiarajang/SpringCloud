package com.zuulgateway.exconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}

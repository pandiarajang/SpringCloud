package com.zuulgateway.exconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExConsumerApplication.class, args);
	}

}

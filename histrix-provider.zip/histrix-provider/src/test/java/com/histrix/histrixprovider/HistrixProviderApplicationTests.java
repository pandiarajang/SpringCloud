package com.histrix.histrixprovider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HistrixProviderApplicationTests {

	@Test
	void contextLoads() {
	}

}

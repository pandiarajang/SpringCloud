package com.ribbon.providerribbon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProviderRibbonApplicationTests {

	@Test
	void contextLoads() {
	}

}
